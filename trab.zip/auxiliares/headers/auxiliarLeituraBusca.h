//Aluno 1: Pedro Luis de Alencar Ribeiro N° USP: 15590852
//Aluno 2: Bianca Duarte Batista Lacerda N° USP: 15443221

//esse arquivo de cabeçalho .h tem como essência definir as funções, variáveis, etc. que podem ser usadas e implementadas por todos os arquivos .c, portanto são funções, estruturas de dados e variáveis auxiliares
#ifndef AUXILIAR_LEITURA_H
#define AUXILIAR_LEITURA_H

//inclui as principais bibliotecas e as únicas utilizadas neste projeto
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

// Estrutura auxiliar para armazenar os campos de um registro(usada para a funcionalidade 3)
struct registro_2 {
    int idPessoa, idadePessoa;
    int tamNomePessoa, tamNomeUsuario;
    char nomePessoa[100];
    char nomeUsuario[100];
};

#endif