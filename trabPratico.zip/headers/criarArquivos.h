//Aluno 1: Pedro Luis de Alencar Ribeiro N° USP: 15590852
//Aluno 2: Bianca Duarte Batista Lacerda N° USP: 15443221

//esse arquivo de cabeçalho .h tem como essência definir as funções, variáveis, etc. que serão usadas e implementadas em create_file.c
#ifndef CREATE_FILE_H
#define CREATE_FILE_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

void criarIndice(char *nomeArquivoIndice);
void criarArquivoDados(char *nomeArquivoEntrada, char *nomeArquivoSaida, char *nomeArquivoIndice);


#endif











